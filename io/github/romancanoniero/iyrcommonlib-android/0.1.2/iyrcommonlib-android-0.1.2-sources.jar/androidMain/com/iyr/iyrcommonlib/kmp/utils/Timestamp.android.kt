package com.iyr.iyrcommonlib.kmp.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal actual fun localTimestamp(): String =
    SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(Date())
