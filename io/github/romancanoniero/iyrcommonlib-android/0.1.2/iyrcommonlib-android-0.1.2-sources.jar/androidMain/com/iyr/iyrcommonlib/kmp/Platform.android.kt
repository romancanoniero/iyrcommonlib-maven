package com.iyr.iyrcommonlib.kmp

internal actual val currentPlatform: PlatformType = PlatformType.ANDROID
