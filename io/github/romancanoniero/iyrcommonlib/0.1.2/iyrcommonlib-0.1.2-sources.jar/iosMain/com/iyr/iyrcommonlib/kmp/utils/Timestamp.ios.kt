package com.iyr.iyrcommonlib.kmp.utils

import platform.Foundation.NSDate
import platform.Foundation.NSDateFormatter
import platform.Foundation.NSLocale
import platform.Foundation.NSTimeZone
import platform.Foundation.localTimeZone

internal actual fun localTimestamp(): String = NSDateFormatter().run {
    locale = NSLocale("en_US_POSIX")
    timeZone = NSTimeZone.localTimeZone
    dateFormat = "yyyyMMdd_HHmmss"
    stringFromDate(NSDate())
}
