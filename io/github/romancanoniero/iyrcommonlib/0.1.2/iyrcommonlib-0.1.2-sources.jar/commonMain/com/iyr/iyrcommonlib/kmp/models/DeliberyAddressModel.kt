package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class DeliberyAddressModel(
    var address_key: String? = null,
    var address_street: String? = null,
    var offline_map_url: String? = null,
    var lat: Double = 0.0,
    var lng: Double = 0.0
)
