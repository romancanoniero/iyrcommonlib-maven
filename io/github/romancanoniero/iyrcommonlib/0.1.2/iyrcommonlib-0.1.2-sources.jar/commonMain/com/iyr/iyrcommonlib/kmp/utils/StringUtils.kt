package com.iyr.iyrcommonlib.kmp.utils

/** String helpers usable from commonMain on Android and iOS. */
object StringUtils {
    /** Signed 32-bit integer, without whitespace or decimal separators. */
    fun isNumber(value: String?): Boolean = value?.toIntOrNull() != null

    /** Prefix plus local yyyyMMdd_HHmmss timestamp. This is not a unique/random identifier. */
    fun generateRandomString(prefix: String?): String = prefix.toString() + localTimestamp()

    /** Sunday = 1, Saturday = 7, matching the original implementation. */
    fun getDayLongName(dayNumber: Int, names: List<String> = dayLongNames): String =
        dayName(dayNumber, names)

    fun getDayShortName(dayNumber: Int, names: List<String> = dayShortNames): String =
        dayName(dayNumber, names)

    private fun dayName(dayNumber: Int, names: List<String>): String {
        require(names.size == 7) { "Supply exactly seven names, starting with Sunday" }
        return if (dayNumber in 1..7) names[dayNumber - 1] else "Error"
    }

    private val dayLongNames = listOf("Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sabado")
    private val dayShortNames = listOf("Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab")
}

internal expect fun localTimestamp(): String
