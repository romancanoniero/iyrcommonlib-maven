package com.iyr.iyrcommonlib.kmp

/** Operating system targeted by the running application. */
enum class PlatformType {
    ANDROID,
    IOS
}

/** Platform information available from commonMain without native SDK imports. */
object Platform {
    /** iOS devices and simulators both return [PlatformType.IOS]. */
    val current: PlatformType
        get() = currentPlatform

    val isAndroid: Boolean
        get() = current == PlatformType.ANDROID

    val isIOS: Boolean
        get() = current == PlatformType.IOS
}

internal expect val currentPlatform: PlatformType
