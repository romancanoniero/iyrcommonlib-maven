package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class ServicesModel(
    var order: Int = 0,
    var module_key: String? = null,
    var service_key: String? = null,
    var service_name: String? = null,
    var logo_image_url: String? = null,
    var translations: MutableList<RecordTranslationModel>? = null
)
