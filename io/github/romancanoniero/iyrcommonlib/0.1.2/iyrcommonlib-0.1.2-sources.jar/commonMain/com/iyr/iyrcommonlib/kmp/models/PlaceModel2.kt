package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class PlaceModel2(
    var isFeatured: Boolean = false,
    var place_key: String? = null,
    var place_name: String? = null,
    var offline_map_url: String? = null,
    var background_image_url: String? = null,
    var logo_image_url: String? = null,
    var products_categories: MutableMap<String, CategoryProductModel>? = null,
    var products: MutableMap<String, ProductModel>? = null
) {
    fun newShoppingCartPlace(): PlaceInShoppingCartModel = PlaceInShoppingCartModel(
        place_key = place_key, place_name = place_name, image_url = logo_image_url
    )
}
