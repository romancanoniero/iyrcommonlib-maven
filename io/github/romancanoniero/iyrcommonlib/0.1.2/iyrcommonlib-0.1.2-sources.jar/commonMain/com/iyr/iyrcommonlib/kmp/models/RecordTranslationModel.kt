package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class RecordTranslationModel(
    var lang_code: String = "",
    var parent_key: String? = null,
    var value: String = "",
    var additional_text: String? = null
) {
    override fun equals(other: Any?): Boolean = other is RecordTranslationModel && lang_code == other.lang_code
    override fun hashCode(): Int = 31 + lang_code.hashCode()
}
