package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class PlaceInShoppingCartModel(
    var place_key: String? = null,
    var place_name: String? = null,
    var image_url: String? = null,
    var total: Double = 0.0
)
