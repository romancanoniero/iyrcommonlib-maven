package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class StoreCategoryModel(
    var category_key: String = "",
    var category_name: String = "",
    var image_url: String = "",
    var selected: Boolean = false
) {
    override fun equals(other: Any?): Boolean = other is StoreCategoryModel && category_key == other.category_key
    override fun hashCode(): Int = 31 + category_key.hashCode()
    /** Shallow copy; nested models and collections are shared, as in the Java API. */
    fun clone(): StoreCategoryModel = StoreCategoryModel(
        category_key = category_key,
        category_name = category_name,
        image_url = image_url,
        selected = selected
    )
}
