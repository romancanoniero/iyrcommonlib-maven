package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class ProductCategoryModel(
    var category_key: String = "",
    var category_name: String = "",
    var logo_image_url: String = "",
    var parent_category: ProductCategoryModel? = null,
    var selected: Boolean = false
) {
    override fun equals(other: Any?): Boolean = other is ProductCategoryModel && category_key == other.category_key
    override fun hashCode(): Int = 31 + category_key.hashCode()
    /** Shallow copy; nested models and collections are shared, as in the Java API. */
    fun clone(): ProductCategoryModel = ProductCategoryModel(
        category_key = category_key,
        category_name = category_name,
        logo_image_url = logo_image_url,
        parent_category = parent_category,
        selected = selected
    )
}
