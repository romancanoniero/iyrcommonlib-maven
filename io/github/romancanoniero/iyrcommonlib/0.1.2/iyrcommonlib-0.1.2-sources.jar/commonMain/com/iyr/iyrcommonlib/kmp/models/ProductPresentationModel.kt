package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class ProductPresentationModel(
    var key: String = "",
    var product_key: String = "",
    var units: Int = 0,
    var price: Float? = null
)
