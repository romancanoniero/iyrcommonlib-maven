package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class ServicesTranslationModel(
    var lang_code: String = "",
    var title: String = "",
    var body_text: String? = null
)
