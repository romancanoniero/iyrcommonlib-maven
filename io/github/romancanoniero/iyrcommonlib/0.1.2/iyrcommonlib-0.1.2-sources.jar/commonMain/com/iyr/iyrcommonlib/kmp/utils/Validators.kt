package com.iyr.iyrcommonlib.kmp.utils

object Validators {
    /** Basic ASCII email syntax check, identical on Android and iOS; does not verify delivery. */
    fun isValidMail(value: String?): Boolean = value != null && email.matches(value)

    fun isValidPassword(value: String?, minLength: Int): Boolean =
        !value.isNullOrEmpty() && value.length >= minLength

    private val email = Regex("[A-Za-z0-9+._%\\-]{1,256}@[A-Za-z0-9][A-Za-z0-9\\-]{0,64}(\\.[A-Za-z0-9][A-Za-z0-9\\-]{0,25})+")
}
