package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class GeoSearchResult(
    var address_as_text: String? = null,
    var lat: Double = 0.0,
    var lng: Double = 0.0,
    var showAs: String? = null,
    var additional_notes: String? = null
) {
    /** Platform geocoders populate these portable fields before calling this method. */
    fun toMap(): Map<String, Any?> = mapOf(
        "address_as_text" to address_as_text, "lat" to lat, "lon" to lng, "showAs" to showAs
    )
    fun toSingleLine(): String = address_as_text.orEmpty().lineSequence().filter { it.isNotBlank() }.joinToString(", ")
}
