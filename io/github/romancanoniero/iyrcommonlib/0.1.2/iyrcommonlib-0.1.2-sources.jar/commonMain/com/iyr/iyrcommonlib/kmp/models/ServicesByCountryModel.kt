package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class ServicesByCountryModel(
    var service_key: String? = null,
    var country_code: String? = null,
    var price: Float = 0.0f,
    var currency_key: String = "",
    var credits: Int = 0,
    var is_free: Boolean = true
)
