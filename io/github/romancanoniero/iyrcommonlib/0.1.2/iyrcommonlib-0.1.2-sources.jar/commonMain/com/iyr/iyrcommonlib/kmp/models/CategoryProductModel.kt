package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class CategoryProductModel(
    var category_key: String? = null,
    var category_name: String? = null,
    var logo_image_url: String? = null,
    var parent_category_key: String? = null
)
