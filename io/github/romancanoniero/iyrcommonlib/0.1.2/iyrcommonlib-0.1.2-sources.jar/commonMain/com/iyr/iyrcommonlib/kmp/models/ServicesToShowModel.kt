package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class ServicesToShowModel(
    var order: Int = 0,
    var module_key: String? = null,
    var service_key: String? = null,
    var service_name: String? = null,
    var service_descripcion: String? = null,
    var logo_image_url: String? = null,
    var price: Float = 0.0f,
    var currency_key: String? = null,
    var credits: Int = 0,
    var is_free: Boolean = false
)
