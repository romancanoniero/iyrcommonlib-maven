package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class UserAddressModel(
    var isLastUser: Boolean = false,
    var address_key: String? = null,
    var address_title: String? = null,
    var address_type: Int = 0,
    var lat: Double = 0.0,
    var lng: Double = 0.0,
    var formatted_address: String? = null,
    var geoLocation: GeoSearchResult? = null,
    var country: String? = null,
    var country_code: String? = null,
    var admin_area: String? = null,
    var localty: String? = null,
    var postal_code: String? = null,
    var isLastAddress: Boolean = false,
    var additional_notes: String? = null
)
