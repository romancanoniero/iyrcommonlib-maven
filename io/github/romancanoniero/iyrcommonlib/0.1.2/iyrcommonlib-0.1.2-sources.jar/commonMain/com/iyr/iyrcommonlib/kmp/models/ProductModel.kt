package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class ProductModel(
    var product_key: String = "",
    var product_name: String = "",
    var product_description: String = "",
    var product_image_url: String = "",
    var product_image_key: String = "",
    var product_price: Float = 0f,
    var product_category: ProductCategoryModel? = null,
    var multiplePresentations: Boolean? = false,
    var presentations: MutableMap<String, ProductPresentationModel>? = null
) {
    fun newShoppingCartProduct(): ProductInShoppingCartModel = ProductInShoppingCartModel(
        product_key = product_key, product_name = product_name,
        product_image_url = product_image_url, product_price = product_price
    )
    fun equalsExact(other: Any?): Boolean = other is ProductModel &&
        product_key == other.product_key && product_name == other.product_name &&
        product_description == other.product_description && product_image_url == other.product_image_url &&
        product_image_key == other.product_image_key && product_price.toBits() == other.product_price.toBits() &&
        product_category == other.product_category && multiplePresentations == other.multiplePresentations &&
        presentations == other.presentations
    override fun equals(other: Any?): Boolean = other is ProductModel && product_key == other.product_key
    override fun hashCode(): Int = 31 + product_key.hashCode()
    /** Shallow copy; nested models and collections are shared, as in the Java API. */
    fun clone(): ProductModel = ProductModel(
        product_key = product_key,
        product_name = product_name,
        product_description = product_description,
        product_image_url = product_image_url,
        product_image_key = product_image_key,
        product_price = product_price,
        product_category = product_category,
        multiplePresentations = multiplePresentations,
        presentations = presentations
    )
}
