package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class PlaceModel(
    var is_featured: Boolean = false,
    var place_key: String = "",
    var place_name: String = "",
    var place_description: String = "",
    var offline_map_url: String = "",
    var background_image_url: String = "",
    var logo_image_url: String = "",
    var telephone: String = "",
    var email: String = "",
    var place_address: UserAddressModel? = null,
    var products_categories: MutableMap<String, CategoryProductModel>? = null,
    var stores_categories: MutableMap<String, StoreCategoryModel>? = null,
    var categories_explained: String = "",
    var storeCategoriesExplained: String = "",
    var products: MutableMap<String, ProductModel>? = null,
    var static_map_url: String? = null
) {
    override fun equals(other: Any?): Boolean = other is PlaceModel && place_key == other.place_key
    override fun hashCode(): Int = 31 + place_key.hashCode()
    fun newShoppingCartPlace(): PlaceInShoppingCartModel = PlaceInShoppingCartModel(
        place_key = place_key, place_name = place_name, image_url = logo_image_url
    )
    /** Shallow copy; nested models and collections are shared, as in the Java API. */
    fun clone(): PlaceModel = PlaceModel(
        is_featured = is_featured,
        place_key = place_key,
        place_name = place_name,
        place_description = place_description,
        offline_map_url = offline_map_url,
        background_image_url = background_image_url,
        logo_image_url = logo_image_url,
        telephone = telephone,
        email = email,
        place_address = place_address,
        products_categories = products_categories,
        stores_categories = stores_categories,
        categories_explained = categories_explained,
        storeCategoriesExplained = storeCategoriesExplained,
        products = products,
        static_map_url = static_map_url
    )
}
