package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class ImagesModel(
    var image_key: String? = null,
    var image_url: String? = null,
    var is_default: Int = 0,
    var order: Int = 0,
    var source_type: Int = 0,
    var is_selected: Boolean = false,
    var status: Int = 0
) {
    companion object {
        const val ADD_OPTION = -1
        const val IMAGE = 0
    }
    override fun equals(other: Any?): Boolean = other is ImagesModel &&
        image_key == other.image_key && image_url == other.image_url && status == other.status
    override fun hashCode(): Int = 31 * (31 + (image_key?.hashCode() ?: 0)) + (image_url?.hashCode() ?: 0)
}
