package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class ModulesModel(
    var module_id: Int = 0,
    var module_key: String? = null,
    var module_name: String? = null,
    var traductions: MutableList<RecordTranslationModel>? = null
)
