package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class AppUserModel(
    var key: String? = null,
    var first_name: String? = null,
    var family_name: String? = null,
    var password: String? = null,
    var display_name: String? = null,
    var photo_url: String? = null,
    var phone_number: String? = null,
    var email: String? = null,
    var lang_code: String? = null,
    var user_key: String? = null,
    var login_method: String? = null
)
