package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class ProductInShoppingCartModel(
    var product_key: String? = null,
    var product_name: String? = null,
    var product_image_url: String? = null,
    var product_price: Float = 0f,
    quantity: Double? = null,
    var item_total: Double? = null
) {
    var quantity: Double? = quantity
        set(value) { field = value; updateItemTotal() }
    fun setPrice(price: Float) {
        product_price = price
        updateItemTotal()
    }
    private fun updateItemTotal() {
        item_total = quantity?.let { product_price * it }
    }
}
