package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class AttachmentModel(
    var attachment_key: String? = null,
    var attachment_url: String? = null,
    var file_type: Int = 0,
    var file_size: Int = 0
)
