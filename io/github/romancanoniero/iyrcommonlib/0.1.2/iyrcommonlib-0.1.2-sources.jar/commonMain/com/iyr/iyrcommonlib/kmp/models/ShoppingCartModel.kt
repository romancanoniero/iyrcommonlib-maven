package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class ShoppingCartModel(
    var addressToDeliber: UserAddressModel? = null,
    var place: PlaceInShoppingCartModel? = null,
    var products: MutableList<ProductInShoppingCartModel>? = mutableListOf()
)
