package com.iyr.iyrcommonlib.kmp.models

/** Portable data model. Platform persistence and UI adapters are supplied by the application. */
class OpeningTimesModel(
    var key: String? = null,
    var day_order: Int = 0,
    var open_24: Boolean = false,
    var is_morning_open: Boolean = false,
    var morning_opens_at: String? = null,
    var morning_closes_at: String? = null,
    var is_close_at_noon: Boolean = false,
    var is_afternoon_open: Boolean = false,
    var afternoon_opens_at: String? = null,
    var afternoon_closes_at: String? = null,
    var is_closed: Boolean = false,
    var similar_days: MutableList<Int>? = null,
    var is_midday_close: Boolean = false
) {
    companion object {
        fun getForADay(dataSet: List<OpeningTimesModel>, dayOfWeek: Int): OpeningTimesModel? =
            dataSet.firstOrNull { it.day_order == dayOfWeek || it.similar_days?.contains(dayOfWeek) == true }
    }
    fun addSimilarDay(dayId: Int) {
        val days = similar_days ?: mutableListOf<Int>().also { similar_days = it }
        days.add(dayId)
    }
    fun isMorningIsOpen(): Boolean = is_morning_open
    fun setMorningIsOpen(value: Boolean) { is_morning_open = value }
    fun getMorningOpen(): String? = morning_opens_at
    fun setMorningOpen(value: String?) { morning_opens_at = value }
    fun getMorningClose(): String? = morning_closes_at
    fun setMorningClose(value: String?) { morning_closes_at = value }
    fun isCloseAtNoon(): Boolean = is_close_at_noon
    fun setCloseAtNoon(value: Boolean) { is_close_at_noon = value }
    /** Shallow copy; nested models and collections are shared, as in the Java API. */
    fun clone(): OpeningTimesModel = OpeningTimesModel(
        key = key,
        day_order = day_order,
        open_24 = open_24,
        is_morning_open = is_morning_open,
        morning_opens_at = morning_opens_at,
        morning_closes_at = morning_closes_at,
        is_close_at_noon = is_close_at_noon,
        is_afternoon_open = is_afternoon_open,
        afternoon_opens_at = afternoon_opens_at,
        afternoon_closes_at = afternoon_closes_at,
        is_closed = is_closed,
        similar_days = similar_days,
        is_midday_close = is_midday_close
    )
    override fun equals(other: Any?): Boolean = other is OpeningTimesModel &&
        key == other.key &&
        day_order == other.day_order &&
        open_24 == other.open_24 &&
        is_morning_open == other.is_morning_open &&
        morning_opens_at == other.morning_opens_at &&
        morning_closes_at == other.morning_closes_at &&
        is_close_at_noon == other.is_close_at_noon &&
        is_afternoon_open == other.is_afternoon_open &&
        afternoon_opens_at == other.afternoon_opens_at &&
        afternoon_closes_at == other.afternoon_closes_at &&
        is_closed == other.is_closed &&
        similar_days == other.similar_days &&
        is_midday_close == other.is_midday_close
    override fun hashCode(): Int = 31 + day_order
}
